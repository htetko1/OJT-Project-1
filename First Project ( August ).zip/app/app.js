// let screenHeight = $(window).height();
//
// $(window).scroll(function () {
//     let current = $(this).scrollTop();
//     // console.log(screenHeight);
//     if (current > screenHeight - 100) {
//         $(".site-nav").addClass("site-nav-scroll");
//     } else {
//         $(".site-nav").removeClass("site-nav-scroll");
//         // setActive("home");
//     }
// });